import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class BreathingSession extends StatefulWidget {
  BreathingSession({super.key});

  @override
  State<BreathingSession> createState() => _BreathingSessionState();
}

class _BreathingSessionState extends State<BreathingSession>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  final AudioPlayer _audioPlayer = AudioPlayer();

  bool isPlaying = false;
  bool _isDragging = false;

  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  @override
  void initState() {
    super.initState();

    // Breathing animation
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);

    _animation = Tween<double>(begin: 1.0, end: 1.4).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    // Audio listeners
    _audioPlayer.onPositionChanged.listen((pos) {
      if (!_isDragging) {
        setState(() => _position = pos);
      }
    });

    _audioPlayer.onDurationChanged.listen((dur) {
      setState(() => _duration = dur);
    });

    _audioPlayer.onPlayerComplete.listen((event) {
      stopSession();
    });
  }

  Future<void> startSession() async {
    await _audioPlayer.play(
      AssetSource('audio/breathing_guide.mp3'),
    );
    setState(() => isPlaying = true);
  }

  Future<void> stopSession() async {
    await _audioPlayer.stop();
    setState(() {
      isPlaying = false;
      _position = Duration.zero;
    });
  }

  Future<void> rewindAudio() async {
    final newPosition = _position - const Duration(seconds: 10);
    await _audioPlayer.seek(
      newPosition > Duration.zero ? newPosition : Duration.zero,
    );
  }

  Future<void> fastForwardAudio() async {
    final newPosition = _position + const Duration(seconds: 10);
    await _audioPlayer.seek(
      newPosition < _duration ? newPosition : _duration,
    );
  }

  String formatTime(Duration d) {
    final minutes = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return "$minutes:$seconds";
  }

  @override
  void dispose() {
    _controller.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Guided Breathing'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedBuilder(
              animation: _animation,
              builder: (context, child) {
                return Transform.scale(
                  scale: _animation.value,
                  child: Container(
                    width: 160,
                    height: 160,
                    decoration: BoxDecoration(
                      color: Colors.teal.shade300,
                      shape: BoxShape.circle,
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 30),

            Text(
              "${formatTime(_position)} / ${formatTime(_duration)}",
              style: const TextStyle(fontSize: 18),
            ),

            // 🎚 SEEK SLIDER
            Slider(
              min: 0,
              max: _duration.inSeconds.toDouble().clamp(1, double.infinity),
              value: _position.inSeconds
                  .toDouble()
                  .clamp(0, _duration.inSeconds.toDouble()),
              onChangeStart: (_) {
                setState(() => _isDragging = true);
              },
              onChanged: (value) {
                setState(() {
                  _position = Duration(seconds: value.toInt());
                });
              },
              onChangeEnd: (value) async {
                await _audioPlayer.seek(
                  Duration(seconds: value.toInt()),
                );
                setState(() => _isDragging = false);
              },
            ),

            const SizedBox(height: 10),

            // ⏪ ⏯ ⏩ CONTROLS
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.replay_10),
                  iconSize: 36,
                  onPressed: isPlaying ? rewindAudio : null,
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: isPlaying ? stopSession : startSession,
                  child: Text(isPlaying ? 'Stop' : 'Start'),
                ),
                const SizedBox(width: 10),
                IconButton(
                  icon: const Icon(Icons.forward_10),
                  iconSize: 36,
                  onPressed: isPlaying ? fastForwardAudio : null,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
